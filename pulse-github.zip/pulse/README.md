# Pulse

Pulse is a local-first social platform combining a photo feed, private messaging, and community servers.

## Run

```bash
cd pulse
npm install
npm run dev
```

Open the printed local URL (usually http://localhost:5173).

## Demo account

- Username: `you`
- Password: `pulse123`
- Every seeded account uses the same password.

## Owner desk

1. Sign in.
2. Open **Owner desk** in the sidebar.
3. Enter owner code: `FERRARI1`
4. You get member list, suspend/restore, verify, wipe posts, reports, and audit log.

## Architecture

- UI: React + Vite
- Data: `src/lib/store.js` — a real data model persisted in `localStorage`
- Seed data: `src/lib/seed.js` (separate from live mutations)
- Auth: SHA-256 password hashing with per-user salt (Web Crypto). Passwords are never stored in plain text.
- Realtime: `BroadcastChannel` + store subscriptions so multiple tabs stay in sync
- Calling: full incoming/outgoing UI and `getUserMedia` preview. Live peer media needs an external WebRTC signaling + ICE server (not bundled).

## What works without extra services

Feed, stories (24h expiry), profiles, follow/friend/block/report, composer (text/image/poll/drafts), likes/comments/saves/share, DMs + groups, community channels + moderation, notifications, search/discover, settings/theme, owner admin.

Connect later if you want production hosting:
- object storage for media
- a WebRTC signaling server (LiveKit, Daily, or custom WebSocket + TURN)
- SMTP for real email verification / password reset delivery
