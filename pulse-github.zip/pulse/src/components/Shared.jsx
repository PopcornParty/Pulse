import { usePulse } from '../context.jsx'
import { initials, timeAgo } from '../lib/format.js'

export function Avatar({ user, className = '' }) {
  if (!user) return <div className={`avatar ${className}`} />
  if (user.avatar) return <img className={`avatar ${className}`} src={user.avatar} alt="" />
  return (
    <div className={`avatar ${className} story-fallback`} style={{ background: `hsl(${user.hue || 20},50%,30%)` }}>
      {initials(user.displayName || user.username)}
    </div>
  )
}

export function Name({ user }) {
  if (!user) return null
  return (
    <strong>
      {user.displayName}
      {user.verified ? <span className="verified" title="Verified">✓</span> : null}
    </strong>
  )
}

export function UserChip({ user, onClick }) {
  return (
    <button className="user-row" onClick={onClick}>
      <Avatar user={user} />
      <div className="who">
        <Name user={user} />
        <span>@{user.username} {user.online ? '· online' : `· ${timeAgo(user.lastActive)}`}</span>
      </div>
    </button>
  )
}

export function Modal({ title, onClose, children, wide }) {
  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal" style={wide ? { width: 'min(820px,100%)' } : undefined} onClick={(e) => e.stopPropagation()}>
        <div className="row" style={{ justifyContent: 'space-between', marginBottom: 12 }}>
          <h3 style={{ margin: 0 }}>{title}</h3>
          <button className="icon-btn" onClick={onClose}>✕</button>
        </div>
        {children}
      </div>
    </div>
  )
}

export function Toasts() {
  const { toasts } = usePulse()
  return (
    <div className="toast-wrap">
      {toasts.map((t) => (
        <div className="toast" key={t.id}>{t.msg}</div>
      ))}
    </div>
  )
}

export function Empty({ title, body }) {
  return (
    <div className="empty">
      <h3>{title}</h3>
      <p>{body}</p>
    </div>
  )
}
