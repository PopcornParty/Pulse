import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { PulseProvider } from './context.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <PulseProvider>
      <App />
    </PulseProvider>
  </StrictMode>,
)
