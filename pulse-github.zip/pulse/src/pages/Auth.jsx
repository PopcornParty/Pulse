import { useState } from 'react'
import { usePulse } from '../context.jsx'
import { DEMO_PASSWORD } from '../lib/seed.js'

export default function AuthScreen() {
  const { api, toast } = usePulse()
  const [mode, setMode] = useState('login')
  const [err, setErr] = useState('')
  const [info, setInfo] = useState('')

  async function onLogin(e) {
    e.preventDefault(); setErr('')
    const f = new FormData(e.target)
    try {
      await api.logIn({ emailOrUsername: f.get('id'), password: f.get('password') })
      toast('Welcome back')
    } catch (ex) { setErr(ex.message) }
  }
  async function onSignup(e) {
    e.preventDefault(); setErr('')
    const f = new FormData(e.target)
    try {
      const res = await api.signUp({
        email: f.get('email'), password: f.get('password'),
        username: f.get('username'), displayName: f.get('name'),
      })
      setInfo(`Account created. Email verification code (demo): ${res.verifyToken}`)
      toast('Account created')
    } catch (ex) { setErr(ex.message) }
  }
  async function onReset(e) {
    e.preventDefault(); setErr('')
    const f = new FormData(e.target)
    try {
      if (!f.get('code')) {
        const code = await api.requestReset(f.get('email'))
        setInfo(`Reset code (local demo): ${code}`)
      } else {
        await api.resetPassword(f.get('email'), f.get('code'), f.get('password'))
        setInfo('Password updated. You can sign in.')
        setMode('login')
      }
    } catch (ex) { setErr(ex.message) }
  }

  return (
    <div className="auth">
      <div className="card auth-card">
        <div className="brand"><div className="brand-mark" /><h1>Pulse</h1></div>
        <h2>{mode === 'signup' ? 'Join the room.' : mode === 'reset' ? 'Reset access.' : 'Pick up the beat.'}</h2>
        <p className="hint">Posts, private chats, and communities — one ecosystem.</p>
        {mode === 'login' && (
          <form onSubmit={onLogin}>
            <div className="field"><label>Email or username</label><input name="id" defaultValue="you" required /></div>
            <div className="field"><label>Password</label><input name="password" type="password" defaultValue={DEMO_PASSWORD} required /></div>
            {err && <p className="error">{err}</p>}
            <button className="btn full" type="submit">Log in</button>
          </form>
        )}
        {mode === 'signup' && (
          <form onSubmit={onSignup}>
            <div className="field"><label>Display name</label><input name="name" required /></div>
            <div className="field"><label>Username</label><input name="username" required /></div>
            <div className="field"><label>Email</label><input name="email" type="email" required /></div>
            <div className="field"><label>Password</label><input name="password" type="password" minLength={6} required /></div>
            {err && <p className="error">{err}</p>}
            {info && <p className="hint">{info}</p>}
            <button className="btn full" type="submit">Create account</button>
          </form>
        )}
        {mode === 'reset' && (
          <form onSubmit={onReset}>
            <div className="field"><label>Email</label><input name="email" type="email" required /></div>
            <div className="field"><label>Reset code</label><input name="code" placeholder="Leave blank to request" /></div>
            <div className="field"><label>New password</label><input name="password" type="password" minLength={6} /></div>
            {err && <p className="error">{err}</p>}
            {info && <p className="hint">{info}</p>}
            <button className="btn full" type="submit">Continue</button>
          </form>
        )}
        <div className="row" style={{ justifyContent: 'space-between', marginTop: 14 }}>
          <button className="ghost" onClick={() => setMode(mode === 'signup' ? 'login' : 'signup')}>{mode === 'signup' ? 'Have an account?' : 'Create account'}</button>
          <button className="ghost" onClick={() => setMode('reset')}>Forgot password</button>
        </div>
        <p className="hint" style={{ marginTop: 16 }}>Demo login: <b>you</b> / <b>{DEMO_PASSWORD}</b></p>
      </div>
    </div>
  )
}
