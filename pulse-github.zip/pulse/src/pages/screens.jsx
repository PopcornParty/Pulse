import { useEffect, useRef, useState } from 'react'
import { usePulse } from '../context.jsx'
import { Avatar, Empty, Modal, Name, UserChip } from '../components/Shared.jsx'
import { fileToDataUrl, prettySize, timeAgo } from '../lib/format.js'

export function userById(db, id) {
  return db.users.find((u) => u.id === id)
}

export function Home() {
  const { db, me, api, go } = usePulse()
  const [tab, setTab] = useState('for-you')
  const [page, setPage] = useState(1)
  const followingIds = db.follows.filter((f) => f.followerId === me.id).map((f) => f.followingId)
  let posts = db.posts.filter((p) => !me.blocked.includes(p.authorId) && !me.muted.includes(p.authorId))
  if (tab === 'following') posts = posts.filter((p) => followingIds.includes(p.authorId) || p.authorId === me.id)
  posts = [...posts].sort((a, b) => b.createdAt - a.createdAt)
  const shown = posts.slice(0, page * 5)
  return (
    <div className="grid-2">
      <div>
        <StoryBar />
        <div className="feed-switch">
          <button className={tab === 'for-you' ? 'on' : ''} onClick={() => setTab('for-you')}>For you</button>
          <button className={tab === 'following' ? 'on' : ''} onClick={() => setTab('following')}>Following</button>
        </div>
        {shown.map((p) => <PostCard key={p.id} post={p} />)}
        {shown.length < posts.length && <button className="btn secondary full" onClick={() => setPage((x) => x + 1)}>Load more</button>}
        {!posts.length && <Empty title="Quiet feed" body="Follow people or switch to For you." />}
      </div>
      <aside>
        <div className="card side-card">
          <h3>Suggested people</h3>
          {db.users.filter((u) => u.id !== me.id && !api.isFollowing(me.id, u.id)).slice(0, 5).map((u) => (
            <div className="row" key={u.id} style={{ justifyContent: 'space-between' }}>
              <UserChip user={u} onClick={() => go(`/u/${u.username}`)} />
              <button className="btn sm" onClick={() => api.follow(me.id, u.id)}>Follow</button>
            </div>
          ))}
        </div>
        <div className="card side-card" style={{ marginTop: 12 }}>
          <h3>Communities nearby</h3>
          {db.communities.slice(0, 4).map((c) => (
            <button key={c.id} className="user-row" onClick={() => go(`/communities/${c.id}`)}>
              <img className="avatar" src={c.icon} alt="" />
              <div className="who"><strong>{c.name}</strong><span>{c.members.length} members</span></div>
            </button>
          ))}
        </div>
      </aside>
    </div>
  )
}

export function StoryBar() {
  const { db, me } = usePulse()
  const [viewer, setViewer] = useState(null)
  const [create, setCreate] = useState(false)
  const live = db.stories.filter((s) => s.expiresAt > Date.now())
  const authors = []
  live.forEach((s) => { if (!authors.includes(s.userId)) authors.push(s.userId) })
  if (!authors.includes(me.id)) authors.unshift(me.id)
  return (
    <>
      <div className="story-row">
        {authors.map((uid) => {
          const user = userById(db, uid)
          const stories = live.filter((s) => s.userId === uid)
          const seen = stories.length && stories.every((s) => s.views.includes(me.id))
          return (
            <button key={uid} className="story-item" onClick={() => stories.length ? setViewer({ uid, i: 0 }) : setCreate(true)}>
              <div className={`story-ring ${uid === me.id && !stories.length ? 'own' : ''} ${seen ? 'seen' : ''}`}>
                {user?.avatar ? <img src={user.avatar} alt="" /> : <div className="story-fallback">+</div>}
              </div>
              {uid === me.id ? 'Your story' : user?.username}
            </button>
          )
        })}
      </div>
      {viewer && (
        <StoryViewer
          stories={live.filter((s) => s.userId === viewer.uid)}
          index={viewer.i}
          onClose={() => setViewer(null)}
          onIndex={(i) => setViewer({ ...viewer, i })}
        />
      )}
      {create && <StoryComposer onClose={() => setCreate(false)} />}
    </>
  )
}

function StoryViewer({ stories, index, onClose, onIndex }) {
  const { me, api, db } = usePulse()
  const s = stories[index]
  useEffect(() => { if (s) api.viewStory(s.id, me.id) }, [s?.id])
  if (!s) return null
  const user = userById(db, s.userId)
  return (
    <div className="overlay" onClick={onClose}>
      <div className="story-viewer" onClick={(e) => e.stopPropagation()}>
        <img src={s.media} alt="" />
        <div style={{ position: 'absolute', top: 12, left: 12 }} className="row">
          <Avatar user={user} className="sm" />
          <span>{user?.displayName} · {timeAgo(s.createdAt)}</span>
        </div>
        <div className="story-caption">{s.emoji} {s.text}</div>
        <button className="ghost" style={{ position: 'absolute', top: 8, right: 8 }} onClick={onClose}>Close</button>
        {s.userId === me.id && <button className="btn sm danger" style={{ position: 'absolute', bottom: 16, right: 16 }} onClick={() => { api.deleteStory(s.id, me.id); onClose() }}>Delete</button>}
        {index > 0 && <button className="carousel-nav l" onClick={() => onIndex(index - 1)}>‹</button>}
        {index < stories.length - 1 && <button className="carousel-nav r" onClick={() => onIndex(index + 1)}>›</button>}
      </div>
    </div>
  )
}

function StoryComposer({ onClose }) {
  const { me, api, toast } = usePulse()
  const [text, setText] = useState('')
  const [emoji, setEmoji] = useState('✨')
  const [media, setMedia] = useState('')
  return (
    <Modal title="New story" onClose={onClose}>
      <div className="field"><label>Photo</label><input type="file" accept="image/*" onChange={async (e) => setMedia(await fileToDataUrl(e.target.files[0]))} /></div>
      {media && <img src={media} alt="" style={{ borderRadius: 12, maxHeight: 240, objectFit: 'cover', width: '100%' }} />}
      <div className="field"><label>Text</label><input value={text} onChange={(e) => setText(e.target.value)} /></div>
      <div className="row">{['✨', '🌙', '🔥', '🌿', '🎵', '📸'].map((em) => <button key={em} className="chip" onClick={() => setEmoji(em)}>{em}</button>)}</div>
      <button className="btn full" style={{ marginTop: 12 }} onClick={() => {
        if (!media) return toast('Add a photo')
        api.createStory(me.id, { media, text, emoji }); toast('Story is live for 24 hours'); onClose()
      }}>Share story</button>
    </Modal>
  )
}

export function PostCard({ post }) {
  const { db, me, api, go, toast } = usePulse()
  const author = userById(db, post.authorId)
  const liked = db.likes.some((l) => l.postId === post.id && l.userId === me.id)
  const saved = db.saves.some((s) => s.postId === post.id && s.userId === me.id)
  const comments = db.comments.filter((c) => c.postId === post.id)
  const likes = db.likes.filter((l) => l.postId === post.id)
  const [slide, setSlide] = useState(0)
  const [openC, setOpenC] = useState(false)
  const [more, setMore] = useState(false)
  const [share, setShare] = useState(false)
  const media = post.media || []
  return (
    <article className="card post">
      <header className="post-head">
        <button className="user-row" onClick={() => go(`/u/${author?.username}`)} style={{ padding: 0 }}>
          <Avatar user={author} />
          <div className="who"><Name user={author} /><span>@{author?.username} · {timeAgo(post.createdAt)}</span></div>
        </button>
        <button className="ghost" style={{ marginLeft: 'auto' }} onClick={() => setMore(true)}>•••</button>
      </header>
      {post.text && <div className="post-text">{post.text} {post.tags?.map((t) => <button key={t} className="hash" onClick={() => go(`/discover?q=${t}`)}> #{t}</button>)}</div>}
      {!!media.length && (
        <div className="post-media">
          {String(media[slide] || '').startsWith('data:video') ? <video src={media[slide]} controls /> : <img src={media[slide]} alt="" />}
          {media.length > 1 && (
            <>
              <button className="carousel-nav l" onClick={() => setSlide((s) => (s ? s - 1 : media.length - 1))}>‹</button>
              <button className="carousel-nav r" onClick={() => setSlide((s) => (s + 1) % media.length)}>›</button>
              <div className="dots">{media.map((_, i) => <i key={i} className={i === slide ? 'on' : ''} />)}</div>
            </>
          )}
        </div>
      )}
      {post.poll && (
        <div className="poll">
          {post.poll.options.map((o) => {
            const total = post.poll.options.reduce((n, x) => n + x.votes.length, 0) || 1
            return (
              <button key={o.id} className="poll-opt" onClick={() => api.votePoll(post.id, o.id, me.id)}>
                <div className="bar" style={{ width: `${(o.votes.length / total) * 100}%` }} />
                <span>{o.text} · {o.votes.length}</span>
              </button>
            )
          })}
        </div>
      )}
      <div className="post-actions">
        <button className={`ghost ${liked ? 'liked' : ''}`} onClick={() => api.toggleLike(post.id, me.id)}>{liked ? '♥' : '♡'} {likes.length}</button>
        <button className="ghost" onClick={() => setOpenC((v) => !v)}>💬 {comments.length}</button>
        <button className="ghost" onClick={() => setShare(true)}>↗ Share</button>
        <button className="ghost" style={{ marginLeft: 'auto' }} onClick={() => api.toggleSave(post.id, me.id)}>{saved ? '★' : '☆'}</button>
      </div>
      <div className="post-meta">{post.views} views</div>
      {openC && (
        <div>
          <div className="comments">
            {comments.map((c) => {
              const u = userById(db, c.userId)
              return (
                <div className="comment" key={c.id}>
                  <Avatar user={u} className="sm" />
                  <div><b>@{u?.username}</b> {c.text} <span className="hint">{timeAgo(c.createdAt)}</span></div>
                </div>
              )
            })}
          </div>
          <form className="composer-row" onSubmit={(e) => { e.preventDefault(); const t = e.target.text.value.trim(); if (!t) return; api.addComment(post.id, me.id, t); e.target.reset() }}>
            <input name="text" placeholder="Write a comment" />
            <button className="btn sm" type="submit">Send</button>
          </form>
        </div>
      )}
      {more && (
        <Modal title="Post options" onClose={() => setMore(false)}>
          {(post.authorId === me.id || api.isOwner(me.id)) && <button className="btn danger full" onClick={() => { api.deletePost(post.id, me.id); setMore(false); toast('Post removed') }}>Delete post</button>}
          <button className="btn secondary full" style={{ marginTop: 8 }} onClick={() => { api.report({ reporterId: me.id, targetType: 'post', targetId: post.id, reason: 'Reported from feed' }); setMore(false); toast('Report sent') }}>Report</button>
          {post.authorId !== me.id && <button className="btn secondary full" style={{ marginTop: 8 }} onClick={() => { api.blockUser(me.id, post.authorId); setMore(false) }}>Block author</button>}
        </Modal>
      )}
      {share && (
        <Modal title="Share" onClose={() => setShare(false)}>
          {db.conversations.filter((c) => c.memberIds.includes(me.id)).map((c) => (
            <button key={c.id} className="user-row" onClick={() => {
              api.sendMessage(c.id, me.id, { text: `Shared a Pulse: ${post.text?.slice(0, 80) || 'a post'}` })
              toast('Shared'); setShare(false); go(`/messages?c=${c.id}`)
            }}>
              <span>{c.name || db.users.find((u) => c.memberIds.includes(u.id) && u.id !== me.id)?.displayName}</span>
            </button>
          ))}
        </Modal>
      )}
    </article>
  )
}

export function Create() {
  const { me, api, toast, go, db } = usePulse()
  const draft = db.drafts.find((d) => d.userId === me.id)
  const [text, setText] = useState(draft?.text || '')
  const [media, setMedia] = useState(draft?.media || [])
  const [type, setType] = useState('image')
  const [pollQ, setPollQ] = useState('')
  const [opts, setOpts] = useState(['', ''])
  const [progress, setProgress] = useState(0)

  async function onFiles(files) {
    const out = []
    for (const f of [...files]) {
      setProgress(40)
      const data = await fileToDataUrl(f)
      out.push(typeof data === 'string' ? data : data.dataUrl)
    }
    setProgress(100)
    setMedia((m) => [...m, ...out])
    setTimeout(() => setProgress(0), 600)
  }

  function publish() {
    const tags = Array.from(text.matchAll(/#(\w+)/g)).map((m) => m[1])
    const payload = { text, media, tags, type: media.length > 1 ? 'carousel' : type }
    if (type === 'poll') {
      payload.type = 'poll'
      payload.poll = { question: pollQ || text, options: opts.filter(Boolean).map((t, i) => ({ id: `n${i}`, text: t, votes: [] })) }
    }
    api.createPost(me.id, payload)
    toast('Posted to Pulse')
    go('/home')
  }

  return (
    <div className="card" style={{ padding: 18, maxWidth: 640 }}>
      <h2 style={{ fontFamily: 'var(--display)', marginTop: 0 }}>Create</h2>
      <div className="row">{['image', 'text', 'poll'].map((t) => <button key={t} className="chip" onClick={() => setType(t)}>{t}</button>)}</div>
      <div className="field"><label>Caption</label><textarea value={text} onChange={(e) => setText(e.target.value)} placeholder="What’s moving?" /></div>
      {type !== 'text' && type !== 'poll' && (
        <div className="field">
          <label>Photos or video</label>
          <input type="file" accept="image/*,video/*" multiple onChange={(e) => onFiles(e.target.files)} />
          {progress > 0 && <div className="poll-opt"><div className="bar" style={{ width: `${progress}%` }} /><span>Uploading {progress}%</span></div>}
          <div className="row" style={{ flexWrap: 'wrap' }}>{media.map((m, i) => <img key={i} src={m} alt="" style={{ width: 88, height: 88, objectFit: 'cover', borderRadius: 10 }} />)}</div>
        </div>
      )}
      {type === 'poll' && (
        <>
          <div className="field"><label>Question</label><input value={pollQ} onChange={(e) => setPollQ(e.target.value)} /></div>
          {opts.map((o, i) => <div className="field" key={i}><label>Option {i + 1}</label><input value={o} onChange={(e) => setOpts(opts.map((x, j) => j === i ? e.target.value : x))} /></div>)}
          <button className="btn secondary sm" onClick={() => setOpts([...opts, ''])}>Add option</button>
        </>
      )}
      <div className="row" style={{ marginTop: 16, gap: 8 }}>
        <button className="btn secondary" onClick={() => { api.saveDraft(me.id, { text, media }); toast('Draft saved') }}>Save draft</button>
        <button className="btn" onClick={publish}>Publish</button>
      </div>
    </div>
  )
}

export function Discover({ query }) {
  const { db, me, api, go } = usePulse()
  const q = (query.q || '').toLowerCase()
  useEffect(() => { if (q) api.addSearchHistory(me.id, q) }, [q])
  const users = db.users.filter((u) => !q || `${u.username} ${u.displayName} ${u.bio}`.toLowerCase().includes(q))
  const posts = db.posts.filter((p) => !q || `${p.text} ${(p.tags || []).join(' ')}`.toLowerCase().includes(q))
  const comms = db.communities.filter((c) => !q || `${c.name} ${c.description}`.toLowerCase().includes(q))
  const tags = [...new Set(db.posts.flatMap((p) => p.tags || []))].filter((t) => !q || t.includes(q))
  const history = db.searchHistory.filter((s) => s.userId === me.id).slice(0, 6)
  return (
    <div>
      {!!history.length && !q && (
        <div className="row" style={{ flexWrap: 'wrap', marginBottom: 12 }}>{history.map((h) => <button key={h.at} className="chip" onClick={() => go(`/discover?q=${h.query}`)}>{h.query}</button>)}</div>
      )}
      <h3>People</h3>
      <div className="card side-card">{users.slice(0, 8).map((u) => (
        <div className="row" key={u.id} style={{ justifyContent: 'space-between' }}>
          <UserChip user={u} onClick={() => go(`/u/${u.username}`)} />
          {u.id !== me.id && <button className="btn sm" onClick={() => api.follow(me.id, u.id)}>{api.isFollowing(me.id, u.id) ? 'Following' : 'Follow'}</button>}
        </div>
      ))}</div>
      <h3>Communities</h3>
      <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
        {comms.map((c) => <button key={c.id} className="chip" onClick={() => go(`/communities/${c.id}`)}>{c.name}</button>)}
      </div>
      <h3>Hashtags</h3>
      <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
        {tags.map((t) => <button key={t} className="chip hash" onClick={() => go(`/discover?q=${t}`)}>#{t}</button>)}
      </div>
      <h3>Trending posts</h3>
      <div className="discover-grid">
        {posts.slice(0, 12).map((p) => (
          <button key={p.id} className="tile" onClick={() => go(`/post/${p.id}`)}>
            {p.media?.[0] ? <img src={p.media[0]} alt="" /> : <div style={{ padding: 10 }}>{p.text}</div>}
          </button>
        ))}
      </div>
    </div>
  )
}

export function PostPage({ id }) {
  const { db } = usePulse()
  const post = db.posts.find((p) => p.id === id)
  if (!post) return <Empty title="Missing post" body="It may have been deleted." />
  return <PostCard post={post} />
}

export function Profile({ username }) {
  const { db, me, api, go } = usePulse()
  const user = db.users.find((u) => u.username === username)
  const [tab, setTab] = useState('posts')
  const [edit, setEdit] = useState(false)
  if (!user) return <Empty title="No one here" body="That username is free." />
  const posts = db.posts.filter((p) => p.authorId === user.id)
  const saved = db.saves.filter((s) => s.userId === user.id).map((s) => db.posts.find((p) => p.id === s.postId)).filter(Boolean)
  const tagged = db.posts.filter((p) => p.taggedUserIds?.includes(user.id))
  const followers = db.follows.filter((f) => f.followingId === user.id)
  const following = db.follows.filter((f) => f.followerId === user.id)
  const friends = db.friends.filter((f) => f.status === 'accepted' && (f.a === user.id || f.b === user.id))
  const mine = user.id === me.id
  const fr = api.friendStatus(me.id, user.id)
  return (
    <div>
      <div className="banner">{user.banner && <img src={user.banner} alt="" />}</div>
      <div className="profile-main">
        <Avatar user={user} className="lg" />
        <div style={{ flex: 1 }}>
          <Name user={user} />
          <div className="hint">@{user.username}</div>
          <p>{user.bio}</p>
          <div className="profile-stats">
            <span><b>{posts.length}</b> posts</span>
            <span><b>{followers.length}</b> followers</span>
            <span><b>{following.length}</b> following</span>
            <span><b>{friends.length}</b> friends</span>
          </div>
        </div>
        <div className="row">
          {mine ? <button className="btn secondary" onClick={() => setEdit(true)}>Edit profile</button> : (
            <>
              <button className="btn" onClick={() => api.follow(me.id, user.id)}>{api.isFollowing(me.id, user.id) ? 'Following' : 'Follow'}</button>
              {fr?.status === 'accepted' ? <button className="btn secondary" onClick={() => api.unfriend(me.id, user.id)}>Friends</button>
                : fr?.status === 'pending' && fr.from !== me.id ? <button className="btn secondary" onClick={() => api.respondFriend(me.id, user.id, true)}>Accept friend</button>
                : fr?.status === 'pending' ? <button className="btn secondary">Requested</button>
                : <button className="btn secondary" onClick={() => api.sendFriendRequest(me.id, user.id)}>Add friend</button>}
              <button className="btn secondary" onClick={() => { const c = api.getOrCreateDm(me.id, user.id); go(`/messages?c=${c.id}`) }}>Message</button>
            </>
          )}
        </div>
      </div>
      <div className="tabs">
        {['posts', 'saved', 'tagged'].map((t) => <button key={t} className={tab === t ? 'on' : ''} onClick={() => setTab(t)}>{t}</button>)}
      </div>
      <div className="masonry">
        {(tab === 'posts' ? posts : tab === 'saved' ? (mine ? saved : []) : tagged).map((p) => (
          <button key={p.id} className="tile" onClick={() => go(`/post/${p.id}`)}>
            {p.media?.[0] ? <img src={p.media[0]} alt="" /> : <div style={{ padding: 8 }}>{p.text}</div>}
          </button>
        ))}
      </div>
      {edit && <EditProfile user={user} onClose={() => setEdit(false)} />}
    </div>
  )
}

function EditProfile({ user, onClose }) {
  const { api, toast } = usePulse()
  const [form, setForm] = useState({ displayName: user.displayName, username: user.username, bio: user.bio || '', links: (user.links || []).join('\n') })
  return (
    <Modal title="Edit profile" onClose={onClose}>
      <div className="field"><label>Photo</label><input type="file" accept="image/*" onChange={async (e) => { const url = await fileToDataUrl(e.target.files[0]); api.updateProfile(user.id, { avatar: url }) }} /></div>
      <div className="field"><label>Display name</label><input value={form.displayName} onChange={(e) => setForm({ ...form, displayName: e.target.value })} /></div>
      <div className="field"><label>Username</label><input value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} /></div>
      <div className="field"><label>Bio</label><textarea value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} /></div>
      <div className="field"><label>Links</label><textarea value={form.links} onChange={(e) => setForm({ ...form, links: e.target.value })} /></div>
      <button className="btn full" onClick={() => {
        try {
          api.updateProfile(user.id, { ...form, links: form.links.split('\n').map((s) => s.trim()).filter(Boolean) })
          toast('Profile updated'); onClose()
        } catch (ex) { toast(ex.message) }
      }}>Save</button>
    </Modal>
  )
}

export function Messages({ startId }) {
  const { db, me, api, toast } = usePulse()
  const convs = db.conversations.filter((c) => c.memberIds.includes(me.id))
  const [cid, setCid] = useState(startId || convs[0]?.id)
  const [text, setText] = useState('')
  const [reply, setReply] = useState(null)
  const [q, setQ] = useState('')
  const [typing, setTyping] = useState(false)
  const [groupOpen, setGroupOpen] = useState(false)
  const [call, setCall] = useState(null)
  const conv = convs.find((c) => c.id === cid)
  const msgs = db.messages.filter((m) => m.conversationId === cid && (!q || (m.text || '').toLowerCase().includes(q.toLowerCase())))
  useEffect(() => { if (cid) api.markRead(cid, me.id) }, [cid, msgs.length])
  const other = conv && (conv.type === 'group' ? null : db.users.find((u) => conv.memberIds.includes(u.id) && u.id !== me.id))

  function send(extra = {}) {
    if (!text.trim() && !extra.media && !extra.file) return
    api.sendMessage(cid, me.id, { text, replyTo: reply?.id, ...extra })
    setText(''); setReply(null); setTyping(false)
  }

  return (
    <div className="msg-layout">
      <div className="msg-list">
        <header>
          <strong>Messages</strong>
          <button className="btn sm" style={{ marginLeft: 'auto' }} onClick={() => setGroupOpen(true)}>New group</button>
        </header>
        {convs.map((c) => {
          const title = c.name || db.users.find((u) => c.memberIds.includes(u.id) && u.id !== me.id)?.displayName
          const last = [...db.messages.filter((m) => m.conversationId === c.id)].pop()
          return (
            <button key={c.id} className={`conv ${c.id === cid ? 'on' : ''}`} onClick={() => setCid(c.id)}>
              <img className="avatar" src={c.image || db.users.find((u) => c.memberIds.includes(u.id) && u.id !== me.id)?.avatar} alt="" />
              <div className="who"><strong>{title}</strong><span>{last?.text?.slice(0, 40) || 'No messages yet'}</span></div>
            </button>
          )
        })}
      </div>
      {conv ? (
        <div className="thread">
          <header>
            <Avatar user={other} />
            <div className="who">
              <strong>{conv.name || other?.displayName}</strong>
              <span>{other?.online ? 'online' : conv.type === 'group' ? `${conv.memberIds.length} members` : 'offline'}</span>
            </div>
            <button className="ghost" onClick={() => setCall(api.startCall({ from: me.id, to: other?.id, type: 'voice', conversationId: cid }))}>Call</button>
            <button className="ghost" onClick={() => setCall(api.startCall({ from: me.id, to: other?.id, type: 'video', conversationId: cid }))}>Video</button>
          </header>
          <div style={{ padding: '8px 14px' }}><input style={{ width: '100%', border: '1px solid var(--line)', background: 'var(--bg-soft)', borderRadius: 999, padding: 8 }} placeholder="Search messages" value={q} onChange={(e) => setQ(e.target.value)} /></div>
          <div className="thread-body">
            {msgs.map((m) => {
              const u = userById(db, m.authorId)
              const mine = m.authorId === me.id
              return (
                <div key={m.id} className={`bubble ${mine ? 'mine' : ''} ${m.deleted ? 'deleted' : ''}`}>
                  {!mine && <div className="hint">@{u?.username}</div>}
                  {m.replyTo && <div className="hint">↩ {db.messages.find((x) => x.id === m.replyTo)?.text}</div>}
                  {m.deleted ? 'Message removed' : m.text}
                  {m.media && <img src={m.media} alt="" style={{ marginTop: 8, borderRadius: 10 }} />}
                  {m.file && <a className="chip" href={m.file.dataUrl} download={m.file.name}>{m.file.name} · {prettySize(m.file.size)}</a>}
                  <div className="meta">
                    {timeAgo(m.createdAt)} {m.editedAt ? '· edited' : ''} {mine ? (m.readBy.length > 1 ? '· read' : '· sent') : ''}
                    <button className="ghost" onClick={() => api.reactMessage(m.id, me.id, '💛')}>💛</button>
                    <button className="ghost" onClick={() => setReply(m)}>Reply</button>
                    {mine && !m.deleted && <button className="ghost" onClick={() => { const t = prompt('Edit message', m.text); if (t != null) api.editMessage(m.id, me.id, t) }}>Edit</button>}
                    <button className="ghost" onClick={() => api.deleteMessage(m.id, me.id)}>Delete</button>
                    <button className="ghost" onClick={() => api.pinMessage(cid, m.id, me.id)}>Pin</button>
                  </div>
                </div>
              )
            })}
            {typing && <div className="hint">You are typing…</div>}
          </div>
          {reply && <div className="hint" style={{ padding: '0 14px' }}>Replying to {reply.text} <button className="ghost" onClick={() => setReply(null)}>x</button></div>}
          <div className="thread-compose">
            <input type="file" accept="image/*" style={{ width: 90 }} onChange={async (e) => { const media = await fileToDataUrl(e.target.files[0]); send({ media }) }} />
            <textarea value={text} onChange={(e) => { setText(e.target.value); setTyping(!!e.target.value) }} placeholder="Message" onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }} />
            <button className="btn" onClick={() => send()}>Send</button>
          </div>
        </div>
      ) : <Empty title="No chat selected" body="Start a conversation from a profile." />}
      {groupOpen && <NewGroup onClose={() => setGroupOpen(false)} onMade={(id) => { setCid(id); setGroupOpen(false) }} />}
      {call && <CallOverlay call={call} onClose={() => { api.endCall(call.id); setCall(null) }} />}
    </div>
  )
}

function NewGroup({ onClose, onMade }) {
  const { db, me, api } = usePulse()
  const [name, setName] = useState('New group')
  const [ids, setIds] = useState([])
  return (
    <Modal title="New group chat" onClose={onClose}>
      <div className="field"><label>Name</label><input value={name} onChange={(e) => setName(e.target.value)} /></div>
      {db.users.filter((u) => u.id !== me.id).map((u) => (
        <label key={u.id} className="user-row">
          <input type="checkbox" checked={ids.includes(u.id)} onChange={() => setIds(ids.includes(u.id) ? ids.filter((x) => x !== u.id) : [...ids, u.id])} />
          <Avatar user={u} className="sm" /> {u.displayName}
        </label>
      ))}
      <button className="btn full" onClick={() => onMade(api.createGroup({ name, memberIds: ids, adminId: me.id }).id)}>Create group</button>
    </Modal>
  )
}

function CallOverlay({ call, onClose }) {
  const { db, api } = usePulse()
  const videoRef = useRef(null)
  const [local, setLocal] = useState({ mic: true, cam: call.type === 'video', speaker: true })
  const [note, setNote] = useState('Signaling is stored in Pulse. Connect a WebRTC server to carry live media.')
  useEffect(() => {
    let stream
    async function boot() {
      if (!navigator.mediaDevices?.getUserMedia) {
        setNote('No media API in this browser. Call UI is ready for WebRTC.')
        return
      }
      try {
        stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: call.type === 'video' })
        if (videoRef.current) videoRef.current.srcObject = stream
        api.updateCall(call.id, { status: 'connected', webrtcReady: true })
      } catch {
        setNote('Camera or mic permission was not granted.')
      }
    }
    boot()
    return () => stream?.getTracks().forEach((t) => t.stop())
  }, [call.id])
  const peer = db.users.find((u) => u.id === call.to) || db.users.find((u) => u.id === call.from)
  return (
    <div className="overlay">
      <div className="call-ui">
        <Avatar user={peer} className="lg" />
        <h2>{call.status === 'ringing' ? 'Calling…' : call.type === 'video' ? 'Video call' : 'Voice call'}</h2>
        <p className="hint">{peer?.displayName}</p>
        <p className="hint">{note}</p>
        {call.type === 'video' && <video ref={videoRef} autoPlay muted playsInline style={{ width: '70%', borderRadius: 16, background: '#111' }} />}
        <div className="call-controls">
          <button onClick={() => setLocal({ ...local, mic: !local.mic })}>{local.mic ? 'Mic' : 'Muted'}</button>
          <button onClick={() => setLocal({ ...local, cam: !local.cam })}>{local.cam ? 'Cam' : 'Cam off'}</button>
          <button onClick={() => setLocal({ ...local, speaker: !local.speaker })}>{local.speaker ? 'Spk' : 'Ear'}</button>
          <button className="end" onClick={onClose}>End</button>
        </div>
      </div>
    </div>
  )
}

export function Communities({ startId }) {
  const { db, me, api, toast } = usePulse()
  const [cid, setCid] = useState(startId || db.communities[0]?.id)
  const cm = db.communities.find((c) => c.id === cid)
  const [ch, setCh] = useState(cm?.categories?.[0]?.channels?.[0]?.id)
  const [text, setText] = useState('')
  const [manage, setManage] = useState(false)
  const [createC, setCreateC] = useState(false)
  useEffect(() => { if (cid) api.visitCommunity(me.id, cid) }, [cid])
  const member = cm?.members.some((m) => m.userId === me.id)
  const msgs = db.communityMessages.filter((m) => m.communityId === cid && m.channelId === ch)
  const channel = cm?.categories.flatMap((c) => c.channels).find((c) => c.id === ch)
  return (
    <div className="comm-layout">
      <div className="server-rail">
        {db.communities.map((c) => (
          <button key={c.id} className={`server-icon ${c.id === cid ? 'on' : ''}`} onClick={() => { setCid(c.id); setCh(c.categories[0]?.channels[0]?.id) }}>
            <img src={c.icon} alt={c.name} />
          </button>
        ))}
        <button className="server-icon" onClick={() => setCreateC(true)}>＋</button>
      </div>
      {cm && (
        <>
          <div className="chan-col">
            <strong style={{ padding: '0 8px' }}>{cm.name}</strong>
            {!member && <button className="btn sm" style={{ margin: 8 }} onClick={() => { api.joinCommunity(cm.id, me.id); toast('Joined') }}>Join</button>}
            {cm.categories.map((cat) => (
              <div key={cat.id}>
                <h4>{cat.name} {api.canModerate(cm, me.id) && <button className="ghost" onClick={() => { const n = prompt('Channel name'); if (n) api.addChannel(cm.id, cat.id, { name: n, type: 'text' }, me.id) }}>+</button>}</h4>
                {cat.channels.map((c) => (
                  <button key={c.id} className={`chan ${c.id === ch ? 'on' : ''}`} onClick={() => setCh(c.id)}>
                    {c.type === 'voice' ? '🔊' : '#'} {c.name}
                  </button>
                ))}
              </div>
            ))}
            {api.canModerate(cm, me.id) && <button className="btn secondary sm" style={{ margin: 8 }} onClick={() => setManage(true)}>Manage</button>}
          </div>
          <div className="thread">
            <header><strong>{channel?.type === 'voice' ? '🔊' : '#'} {channel?.name}</strong></header>
            {channel?.type === 'voice' ? (
              <div className="empty">
                <p>Voice room ready. Connect WebRTC signaling to carry live audio.</p>
                <button className="btn" onClick={() => api.startCall({ from: me.id, type: 'voice', conversationId: channel.id })}>Join voice</button>
              </div>
            ) : (
              <>
                <div className="thread-body">
                  {msgs.map((m) => {
                    const u = userById(db, m.authorId)
                    return (
                      <div key={m.id} className="bubble">
                        <b>@{u?.username}</b> {m.deleted ? <i>removed</i> : m.text}
                        <div className="meta">
                          {timeAgo(m.createdAt)}
                          <button className="ghost" onClick={() => api.reactCommunityMessage(m.id, me.id, '🔥')}>🔥</button>
                          {(m.authorId === me.id || api.canModerate(cm, me.id)) && <button className="ghost" onClick={() => api.deleteCommunityMessage(m.id, me.id)}>Delete</button>}
                        </div>
                      </div>
                    )
                  })}
                </div>
                {member && (
                  <div className="thread-compose">
                    <textarea value={text} onChange={(e) => setText(e.target.value)} placeholder={`Message #${channel?.name || ''}`} />
                    <button className="btn" onClick={() => { if (!text.trim()) return; api.sendCommunityMessage(cm.id, ch, me.id, { text }); setText('') }}>Send</button>
                  </div>
                )}
              </>
            )}
          </div>
          <div className="member-col">
            <h4>Members</h4>
            {cm.members.map((m) => <UserChip key={m.userId} user={userById(db, m.userId)} onClick={() => {}} />)}
          </div>
        </>
      )}
      {manage && <ManageCommunity cm={cm} onClose={() => setManage(false)} />}
      {createC && (
        <Modal title="New community" onClose={() => setCreateC(false)}>
          <form onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.target); const c = api.createCommunity({ name: f.get('name'), description: f.get('desc'), ownerId: me.id }); setCid(c.id); setCreateC(false) }}>
            <div className="field"><label>Name</label><input name="name" required /></div>
            <div className="field"><label>Description</label><textarea name="desc" /></div>
            <button className="btn full">Create</button>
          </form>
        </Modal>
      )}
    </div>
  )
}

function ManageCommunity({ cm, onClose }) {
  const { db, me, api, toast } = usePulse()
  return (
    <Modal title={`Manage ${cm.name}`} onClose={onClose} wide>
      <p className="hint">Invite code: {cm.invites[0]?.code}</p>
      {cm.members.map((m) => {
        const u = userById(db, m.userId)
        return (
          <div className="row" key={m.userId} style={{ justifyContent: 'space-between', margin: '6px 0' }}>
            <span>@{u?.username}</span>
            <span>
              <button className="btn sm secondary" onClick={() => { api.warnUser(cm.id, m.userId, me.id, 'Please keep it kind'); toast('Warned') }}>Warn</button>
              <button className="btn sm secondary" onClick={() => api.kickMember(cm.id, m.userId, me.id)}>Kick</button>
              <button className="btn sm danger" onClick={() => api.banMember(cm.id, m.userId, me.id, 'Banned by mod')}>Ban</button>
            </span>
          </div>
        )
      })}
    </Modal>
  )
}

export function Notifications() {
  const { db, me, api, go } = usePulse()
  const notes = db.notifications.filter((n) => n.userId === me.id)
  const labels = {
    like: 'liked your post', comment: 'commented', follow: 'followed you',
    friend_request: 'sent a friend request', friend_accept: 'accepted your friend request',
    message: 'sent a message', mention: 'mentioned you', invite: 'invited you to a community',
    story: 'viewed your story', warn: 'sent a warning',
  }
  return (
    <div className="card" style={{ padding: 8 }}>
      <div className="row" style={{ justifyContent: 'space-between', padding: 8 }}>
        <h3 style={{ margin: 0 }}>Activity</h3>
        <button className="btn sm secondary" onClick={() => api.markNotificationsRead(me.id)}>Mark all read</button>
      </div>
      {notes.map((n) => {
        const actor = userById(db, n.actorId)
        return (
          <button key={n.id} className="user-row" onClick={() => { api.markNotificationsRead(me.id, [n.id]); go('/home') }}>
            <Avatar user={actor} />
            <div className="who">
              <strong>{actor?.displayName} <span style={{ fontWeight: 500, color: 'var(--muted)' }}>{labels[n.type] || n.type}</span></strong>
              <span>{timeAgo(n.createdAt)} {n.read ? '' : '· new'}</span>
            </div>
          </button>
        )
      })}
    </div>
  )
}

export function Settings() {
  const { me, api, db, toast, go } = usePulse()
  const [tab, setTab] = useState('account')
  const sessions = db.sessions.filter((s) => s.userId === me.id)
  return (
    <div className="settings-grid">
      <div className="settings-nav card" style={{ padding: 8 }}>
        {['account', 'privacy', 'notifications', 'appearance', 'security'].map((t) => (
          <button key={t} className={tab === t ? 'on' : ''} onClick={() => setTab(t)}>{t}</button>
        ))}
      </div>
      <div className="card" style={{ padding: 18 }}>
        {tab === 'account' && (
          <>
            <div className="field"><label>Email</label><input defaultValue={me.email} onBlur={(e) => api.updateProfile(me.id, { email: e.target.value })} /></div>
            <form onSubmit={async (e) => { e.preventDefault(); const f = new FormData(e.target); try { await api.changePassword(me.id, f.get('cur'), f.get('next')); toast('Password updated') } catch (ex) { toast(ex.message) } }}>
              <div className="field"><label>Current password</label><input name="cur" type="password" /></div>
              <div className="field"><label>New password</label><input name="next" type="password" /></div>
              <button className="btn">Change password</button>
            </form>
          </>
        )}
        {tab === 'privacy' && (
          <>
            {[['privateAccount', 'Private account'], ['activity', 'Show activity']].map(([k, l]) => (
              <label key={k} className="row" style={{ margin: '10px 0' }}>
                <input type="checkbox" defaultChecked={!!me.privacy[k]} onChange={(e) => api.updatePrivacy(me.id, { [k]: e.target.checked })} /> {l}
              </label>
            ))}
            <div className="field"><label>Who can message you</label>
              <select defaultValue={me.privacy.messagePerm} onChange={(e) => api.updatePrivacy(me.id, { messagePerm: e.target.value })}>
                <option value="everyone">Everyone</option><option value="friends">Friends</option><option value="none">No one</option>
              </select>
            </div>
          </>
        )}
        {tab === 'notifications' && Object.keys(me.settings.notifPush).map((k) => (
          <label key={k} className="row" style={{ margin: '8px 0' }}>
            <input type="checkbox" defaultChecked={me.settings.notifPush[k]} onChange={(e) => api.updateSettings(me.id, { notifPush: { ...me.settings.notifPush, [k]: e.target.checked } })} /> Push: {k}
          </label>
        ))}
        {tab === 'appearance' && (
          <div className="row">{['dark', 'light', 'system'].map((t) => <button key={t} className="chip" onClick={() => api.updateSettings(me.id, { theme: t })}>{t}</button>)}</div>
        )}
        {tab === 'security' && (
          <>
            {sessions.map((s) => <div key={s.token} className="hint">{s.device} · {timeAgo(s.createdAt)}</div>)}
            <button className="btn danger" style={{ marginTop: 12 }} onClick={() => { api.logoutAll(me.id); go('/') }}>Log out everywhere</button>
          </>
        )}
      </div>
    </div>
  )
}

export function Admin() {
  const { me, api, db, toast } = usePulse()
  const [code, setCode] = useState('')
  const owner = api.isOwner(me.id)
  if (!owner) {
    return (
      <div className="card" style={{ padding: 24, maxWidth: 480 }}>
        <h2 style={{ fontFamily: 'var(--display)' }}>Owner desk</h2>
        <p className="hint">Enter the owner code to open the platform control room.</p>
        <div className="field"><label>Owner code</label><input value={code} onChange={(e) => setCode(e.target.value)} /></div>
        <button className="btn" onClick={() => { try { api.unlockOwner(me.id, code.trim()); toast('Owner access granted') } catch (ex) { toast(ex.message) } }}>Unlock</button>
      </div>
    )
  }
  return (
    <div>
      <h2 style={{ fontFamily: 'var(--display)' }}>Owner control room</h2>
      <div className="card" style={{ padding: 12, marginBottom: 16, overflow: 'auto' }}>
        <h3>Members ({db.users.length})</h3>
        <table className="admin-table">
          <thead><tr><th>User</th><th>Email</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            {db.users.map((u) => {
              const banned = db.platformBans.some((b) => b.userId === u.id && b.active)
              return (
                <tr key={u.id}>
                  <td>@{u.username} {u.verified ? '✓' : ''}</td>
                  <td>{u.email}</td>
                  <td>{banned ? 'suspended' : u.online ? 'online' : 'offline'}</td>
                  <td>
                    <button className="btn sm secondary" onClick={() => api.verifyUser(me.id, u.id, !u.verified)}>{u.verified ? 'Unverify' : 'Verify'}</button>
                    <button className="btn sm secondary" onClick={() => api.ownerKickUser(me.id, u.id)}>Kick sessions</button>
                    <button className="btn sm secondary" onClick={() => api.ownerDeleteUserContent(me.id, u.id)}>Wipe posts</button>
                    {banned
                      ? <button className="btn sm" onClick={() => api.ownerUnsuspend(me.id, u.id)}>Restore</button>
                      : <button className="btn sm danger" onClick={() => api.ownerSuspend(me.id, u.id, 'Suspended by owner')}>Suspend</button>}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
      <div className="card" style={{ padding: 12, marginBottom: 16 }}>
        <h3>Reports</h3>
        {db.reports.map((r) => (
          <div key={r.id} className="row" style={{ justifyContent: 'space-between', padding: 8 }}>
            <span>{r.targetType} · {r.reason} · {r.status}</span>
            <button className="btn sm secondary" onClick={() => api.resolveReport(me.id, r.id, 'resolved')}>Resolve</button>
          </div>
        ))}
      </div>
      <div className="card" style={{ padding: 12 }}>
        <h3>Audit log</h3>
        {db.auditLog.slice(0, 20).map((a) => <div key={a.id} className="hint">{a.action} · {timeAgo(a.at)}</div>)}
        <button className="btn danger" style={{ marginTop: 16 }} onClick={() => { if (confirm('Reset all Pulse data to demo?')) { api.resetDemo(); location.reload() } }}>Reset demo database</button>
      </div>
    </div>
  )
}
