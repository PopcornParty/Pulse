import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import * as api from './lib/store.js'
import { applyTheme } from './lib/format.js'

const Pulse = createContext(null)

function readHash() {
  const raw = (window.location.hash || '#/').replace(/^#/, '')
  return raw.startsWith('/') ? raw : '/' + raw
}

export function PulseProvider({ children }) {
  const [ready, setReady] = useState(false)
  const [tick, setTick] = useState(0)
  const [toasts, setToasts] = useState([])
  const [path, setPath] = useState(() => readHash())

  useEffect(() => {
    api.initStore().then(() => {
      setReady(true)
      setTick((t) => t + 1)
    })
    return api.subscribe(() => setTick((t) => t + 1))
  }, [])

  useEffect(() => {
    const onHash = () => setPath(readHash())
    window.addEventListener('hashchange', onHash)
    return () => window.removeEventListener('hashchange', onHash)
  }, [])

  const toast = (msg) => {
    const id = Math.random().toString(36).slice(2)
    setToasts((t) => [...t, { id, msg }])
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2800)
  }

  const go = (to) => {
    const next = to.startsWith('/') ? to : '/' + to
    window.location.hash = next
    setPath(next)
    window.scrollTo(0, 0)
  }

  const db = ready ? api.getDb() : null
  const me = ready ? api.currentUser() : null

  useEffect(() => {
    if (me?.settings?.theme) applyTheme(me.settings.theme)
    else applyTheme('dark')
  }, [me?.settings?.theme, tick])

  const value = useMemo(
    () => ({ ready, db, me, api, go, path, toast, toasts, tick }),
    [ready, db, me, path, toasts, tick],
  )

  return <Pulse.Provider value={value}>{children}</Pulse.Provider>
}

export function usePulse() {
  return useContext(Pulse)
}
