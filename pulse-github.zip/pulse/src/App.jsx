import { usePulse } from './context.jsx'
import { Toasts } from './components/Shared.jsx'
import AuthScreen from './pages/Auth.jsx'
import {
  Admin, Communities, Create, Discover, Home, Messages,
  Notifications, PostPage, Profile, Settings,
} from './pages/screens.jsx'

function parsePath(path) {
  const [p, q] = path.split('?')
  const parts = p.split('/').filter(Boolean)
  const query = Object.fromEntries(new URLSearchParams(q || ''))
  return { parts, query }
}

export default function App() {
  const ctx = usePulse()
  if (!ctx.ready) {
    return (
      <div className="auth">
        <div className="card auth-card">
          <div className="brand"><div className="brand-mark" /><h1>Pulse</h1></div>
          <p className="hint">Warming up the room…</p>
        </div>
      </div>
    )
  }
  if (!ctx.me) return <AuthScreen />
  return (
    <>
      <Shell />
      <Toasts />
    </>
  )
}

function Shell() {
  const { path, go, me, db, api } = usePulse()
  const { parts, query } = parsePath(path)
  const route = parts[0] || 'home'
  const unread = db.notifications.filter((n) => n.userId === me.id && !n.read).length
  const unreadMsg = db.conversations
    .filter((c) => c.memberIds.includes(me.id))
    .reduce((n, c) => n + db.messages.filter((m) => m.conversationId === c.id && !m.readBy.includes(me.id)).length, 0)

  const nav = [
    ['home', 'Home', '/home'],
    ['discover', 'Discover', '/discover'],
    ['create', 'Create', '/create'],
    ['messages', 'Messages', '/messages'],
    ['communities', 'Communities', '/communities'],
    ['notifications', 'Activity', '/notifications'],
    ['profile', 'Profile', `/u/${me.username}`],
    ['settings', 'Settings', '/settings'],
  ]

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><div className="brand-mark" /><h1>Pulse</h1></div>
        {nav.map(([key, label, href]) => (
          <button key={key} className={`nav-btn ${route === key || (route === 'u' && key === 'profile') ? 'active' : ''}`} onClick={() => go(href)}>
            {label}
            {key === 'notifications' && unread ? <span className="badge">{unread}</span> : null}
            {key === 'messages' && unreadMsg ? <span className="badge">{unreadMsg}</span> : null}
          </button>
        ))}
        <div className="sidebar-foot">
          <button className="nav-btn" onClick={() => go('/admin')}>Owner desk</button>
          <button className="user-row" onClick={() => go(`/u/${me.username}`)}>
            <img className="avatar" src={me.avatar} alt="" />
            <div className="who"><strong>{me.displayName}</strong><span>@{me.username}</span></div>
          </button>
          <button className="nav-btn" onClick={() => { api.logOut(); go('/') }}>Log out</button>
        </div>
      </aside>
      <main className="main">
        {route !== 'messages' && route !== 'communities' && (
          <div className="topbar">
            <div className="search-pill">
              <span>⌕</span>
              <input
                placeholder="Search people, posts, communities…"
                defaultValue={query.q || ''}
                onKeyDown={(e) => { if (e.key === 'Enter') go(`/discover?q=${encodeURIComponent(e.target.value)}`) }}
              />
            </div>
            <button className="icon-btn" onClick={() => go('/notifications')}>
              ⌁{unread ? <i className="dot" /> : null}
            </button>
            <button className="icon-btn" onClick={() => go('/create')}>＋</button>
          </div>
        )}
        <Router route={route} parts={parts} query={query} />
      </main>
      <nav className="bottom-nav">
        {[['home','Home','/home'],['discover','Discover','/discover'],['create','Create','/create'],['messages','Chats','/messages'],['profile','You',`/u/${me.username}`]].map(([k,l,h]) => (
          <button key={k} className={route === k || (route === 'u' && k === 'profile') ? 'on' : ''} onClick={() => go(h)}>{l}</button>
        ))}
      </nav>
    </div>
  )
}

function Router({ route, parts, query }) {
  if (route === 'home') return <Home />
  if (route === 'discover') return <Discover query={query} />
  if (route === 'create') return <Create />
  if (route === 'messages') return <Messages startId={query.c} />
  if (route === 'communities') return <Communities startId={parts[1]} />
  if (route === 'notifications') return <Notifications />
  if (route === 'settings') return <Settings />
  if (route === 'admin') return <Admin />
  if (route === 'u') return <Profile username={parts[1]} />
  if (route === 'post') return <PostPage id={parts[1]} />
  return <Home />
}
